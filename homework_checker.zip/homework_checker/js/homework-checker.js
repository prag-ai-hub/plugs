jQuery(document).ready(function($) {
    console.log('Homework Checker initialized');

    // Hide actions initially
    $('#hwc-actions').hide();

    // Define allowed file types
    const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/jpg', 'image/png'];
    const ALLOWED_DOC_TYPES = ['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain'];
    const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB limit

    // Event listener for question type change
    $('#question-type').on('change', function() {
        const questionType = $(this).val();
        console.log('Question type changed to:', questionType);

        // Update file input attributes and labels based on question type
        if (questionType === 'mcq') {
            $('#teacher-file, #student-file').attr('accept', '.doc,.docx,.pdf,.txt');
            $('#label-teacher-file').html('<b>Upload Answer Key:</b>');
            $('#label-student-file').html('<b>Upload Student\'s MCQ Response:</b>');
        } else {
            $('#teacher-file, #student-file').attr('accept', '.jpg,.jpeg,.png');
            $('#label-teacher-file').html('<b>Upload Teacher\'s Model Answer:</b>');
            $('#label-student-file').html('<b>Upload Student\'s Answer:</b>');
        }
    });

    // File input change handlers for validation
    $('#teacher-file, #student-file').on('change', function() {
        const file = this.files[0];
        const inputId = $(this).attr('id');
        const questionType = $('#question-type').val();

        console.log(`File selected for ${inputId}:`, file ? {
            name: file.name,
            type: file.type,
            size: file.size
        } : 'No file selected');

        if (file) {
            const validationResult = validateFile(file, questionType);
            if (!validationResult.isValid) {
                console.error(`Validation failed for ${inputId}:`, validationResult.error);
                $(this).val(''); // Clear the invalid file
                showError(validationResult.error);
            }
        }
    });

    // File validation function
    function validateFile(file, questionType) {
        console.log('Validating file:', file.name, 'for question type:', questionType);

        // Check file size
        if (file.size > MAX_FILE_SIZE) {
            return {
                isValid: false,
                error: `File size exceeds 5MB limit (${(file.size / 1024 / 1024).toFixed(2)}MB)`
            };
        }

        // Check file type based on question type
        if (questionType === 'subjective') {
            if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
                return {
                    isValid: false,
                    error: 'For subjective questions, please upload only image files (JPG, JPEG, or PNG)'
                };
            }
        } else {
            if (!ALLOWED_DOC_TYPES.includes(file.type)) {
                return {
                    isValid: false,
                    error: 'For MCQ questions, please upload only document files (PDF, DOCX, or TXT)'
                };
            }
        }

        console.log('File validation passed');
        return { isValid: true };
    }

    // Event listener for the "Submit" button
    $('#check-homework-btn').on('click', function(e) {
        e.preventDefault();
        console.log('Submit button clicked');

        let teacherFileInput = $('#teacher-file')[0];
        let studentFileInput = $('#student-file')[0];
        let questionType = $('#question-type').val();
        let teacherFile = teacherFileInput.files[0];
        let studentFile = studentFileInput.files[0];

        // Validate file uploads
        if (!teacherFile || !studentFile) {
            console.error('Missing files');
            showError('Please upload both the teacher\'s and student\'s files.');
            return;
        }

        // Validate both files
        const teacherFileValidation = validateFile(teacherFile, questionType);
        const studentFileValidation = validateFile(studentFile, questionType);

        if (!teacherFileValidation.isValid) {
            showError('Teacher file: ' + teacherFileValidation.error);
            return;
        }
        if (!studentFileValidation.isValid) {
            showError('Student file: ' + studentFileValidation.error);
            return;
        }

        // Show loading state
        showLoading();

        // Prepare form data
        let formData = new FormData();
        formData.append('action', 'check_homework');
        formData.append('teacher_file', teacherFile);
        formData.append('student_file', studentFile);
        formData.append('question_type', questionType);

        console.log('Submitting files for analysis:', {
            teacherFile: teacherFile.name,
            studentFile: studentFile.name,
            questionType: questionType
        });

        // AJAX request
        $.ajax({
            url: homeworkChecker.ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            // success: function(response) {
            //     console.log('Server response received:', response);
            //     if (response.success) {
            //         let formattedResponse = questionType === 'mcq' ?
            //             formatMCQResponse(response.data) :
            //             formatSubjectiveResponse(response.data);
            //         $('#content-output').html(formattedResponse);
            //         $('#hwc-actions').show();
            //     } else {
            //         console.error('Server returned error:', response.data);
            //         if (response.data && response.data.includes('You have reached your tool usage limit')) {
            //             showError(response.data);
            //         } else {
            //             showError('Error analyzing the submission. Please try again.');
            //         }
            //     }
            // },
            success: function(response) {
                console.log('Server response received:', response);
                if (response.success) {
                    let formattedResponse = questionType === 'mcq' ?
                        formatMCQResponse(response.data) :
                        formatSubjectiveResponse(response.data);
                    $('#content-output').html(formattedResponse);
                    $('#hwc-actions').show();
                } else {
                    console.error('Server returned error:', response.data);

                    // Handle specific error cases
                    if (response.data.includes('OpenRouter API key is not configured')) {
                        showError('The OpenRouter API key is not configured. Please contact the administrator to set up the API key.');
                    } else if (response.data.includes('You have reached your tool usage limit')) {
                        showError(response.data);
                    } else if (response.data.includes('API Error')) {
                        showError('There was an error communicating with the API. Please try again later.');
                    } else {
                        showError('Error analyzing the submission. Please try again.');
                    }
                }
            },

            error: function(xhr, status, error) {
                console.error('AJAX Error:', { xhr, status, error });
                showError('An error occurred. Please try again.');
            }
        });
    });

    // Helper functions for UI feedback
    function showError(message) {
        console.error('Showing error:', message);
        $('.generated-content').show();
        $('#content-output').show().html(`<p style="color: red;">${message}</p>`);
    }

    function showLoading() {
        console.log('Showing loading state');
        $('.generated-content').show();
        $('#content-output').show().html('Analyzing submission... Please wait!');
    }

    // Format MCQ responses
    function formatMCQResponse(response) {
        console.log('Formatting MCQ response');
        let formatted = '';
        let lines = response.split('\n');
        let inList = false;

        lines.forEach(line => {
            line = line.trim();
            if (line) {
                if (line.startsWith("Correct Answers:") || line.startsWith("Incorrect Answers:")) {
                    if (inList) {
                        formatted += '</ul>';
                        inList = false;
                    }
                    formatted += `<p><strong>${line}</strong></p>`;
                    formatted += '<ul style="list-style-type: none; padding-left: 20px;">';
                    inList = true;
                } else if (line.startsWith("Summary:")) {
                    if (inList) {
                        formatted += '</ul>';
                        inList = false;
                    }
                    let summaryParts = line.split(": ");
                    formatted += `<p><strong>${summaryParts[0]}:</strong> ${summaryParts[1]}</p>`;
                } else {
                    formatted += `<li>${line}</li>`;
                }
            }
        });

        if (inList) {
            formatted += '</ul>';
        }

        return formatted;
    }

    // Format subjective responses
    function formatSubjectiveResponse(response) {
        console.log('Formatting subjective response');
        let formatted = '';
        let lines = response.split('\n');
        let currentSection = '';
        let inList = false;

        lines.forEach(line => {
            line = line.trim();
            if (!line) return;

            // Handle main section headers with bold formatting
            if (line.startsWith("1. Strengths") ||
                line.startsWith("2. Points breakdown") ||
                line.startsWith("3. Areas for Improvement")) {
                if (inList) {
                    formatted += '</ul>';
                    inList = false;
                }
                currentSection = line.split('.')[1].trim();
                formatted += `<div class="evaluation-section">`;
                formatted += `<h4 class="section-header"><strong>${currentSection}</strong></h4>`; // Added strong tag
                formatted += '<ul class="evaluation-list">';
                inList = true;
            }
            // Handle the summary section
            else if (line.startsWith("Content Coverage:")) {
                if (inList) {
                    formatted += '</ul>';
                    inList = false;
                }
                formatted += `<div class="summary-section">`;
                formatted += `<h4 class="section-header"><strong>Summary</strong></h4>`;
                formatted += `<p>${line.replace('Summary:', '').trim()}</p>`;
                formatted += '</div>';
            }
            // Handle points and scores
            else if (line.startsWith("-") || line.match(/^[A-Za-z\s]+:/)) {
                if (!inList) {
                    formatted += '<ul class="evaluation-list">';
                    inList = true;
                }
                if (currentSection === "Points breakdown") {
                    let [category, score] = line.replace('-', '').split(':').map(item => item.trim());
                    formatted += `<li><span class="category"><strong>${category}:</strong></span> <span class="score">${score}</span></li>`;
                } else {
                    formatted += `<li>${line.replace('-', '').trim()}</li>`;
                }
            }
        });

        if (inList) {
            formatted += '</ul></div>';
        }

        // Add overall score section if not present
        if (!response.includes('Overall Score:')) {
            formatted += `
                <div class="overall-score-section">
                    <h4 class="section-header"><strong>Overall Assessment</strong></h4>
                    <div class="score-display">
                        <span class="total-score">Overall Score: ${calculateOverallScore(response)}/10</span>
                    </div>
                </div>
            `;
        }

        return formatted;
    }

    // Helper function to calculate overall score
    function calculateOverallScore(response) {
        const scores = response.match(/\d+\/10/g);
        if (!scores) return "N/A";

        const total = scores.reduce((sum, score) => {
            return sum + parseInt(score);
        }, 0);

        return (total / scores.length).toFixed(1);
    }

    // Clear button handler
    $('#clear-hwc').on('click', function() {
        console.log('Clearing form');
        $('#teacher-file').val('');
        $('#student-file').val('');
        $('#content-output').empty();
        $('#content-output').hide();
        $('.generated-content').hide();
        $('#hwc-actions').hide();
    });
});  