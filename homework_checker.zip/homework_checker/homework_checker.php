<?php
// [Start] Plugin details ############################################################################################################################################
/**
 * Plugin Name: Homework Checker
 * Description: A tool to check homework by selecting an OpenAI model and uploading files.
 * Version: 1.0
 * Author: Pragmatic Techsoft Pvt. Ltd.
 */
// [End] Plugin details ###############################################################################################################################################

// undefinedFunction();

// Include Composer's autoload file for loading dependencies (e.g., PDF and DOCX parsers) ##############################################################################
require_once plugin_dir_path(__FILE__) . 'vendor/autoload.php';

// [Start] Enqueue styles and scripts for the Homework Checker plugin ##################################################################################################
function homework_checker_enqueue_scripts() {
    wp_enqueue_style('homework-checker-style', plugins_url('css/homework-checker.css', __FILE__));
    wp_enqueue_script('homework-checker-script', plugins_url('js/homework-checker.js', __FILE__), array('jquery'), null, true);

    // Localize the script with the AJAX URL ####################################################################################################
     wp_localize_script('homework-checker-script', 'homeworkChecker', array(
        'ajaxurl' => admin_url('admin-ajax.php')
    ));
}
// [End] Enqueue styles and scripts for the Homework Checker plugin ##################################################################################################

// Hook the script and style enqueue function to the WordPress frontend ################################################################################################
add_action('wp_enqueue_scripts', 'homework_checker_enqueue_scripts');

// Register AJAX handlers for logged-in and non-logged-in users ########################################################################################################
add_action('wp_ajax_check_homework', 'handle_homework_check');
add_action('wp_ajax_nopriv_check_homework', 'handle_homework_check');

// Register a shortcode to display the Homework Checker UI on any page or post ##########################################################################################
add_shortcode('homework_checker', 'homework_checker_display_ui');


// [Start] Function to display the Homework Checker UI ###################################################################################################################
function homework_checker_display_ui() {
    ob_start();
    ?>

<a href="http://localhost/eduaihub/tools/" id="back-to-tools" style="display: inline-flex; align-items: center;">
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M19 12H5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M12 19L5 12L12 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
    Back to Tools
</a>
    <div class="homework-checker-container">
        <h2>Homework Checker</h2>

          <!-- Add Question Type Selector -->
          <div class="question-type-selector">
            <label for="question-type"><b>Select Question Type:</b></label>
            <select id="question-type" name="question-type">
                <option value="mcq">Multiple Choice Questions (MCQ)</option>
                <option value="subjective">Subjective Questions</option>
            </select>
        </div>
        
        <div class="file-upload">
            <label for="teacher-file" id="label-teacher-file"><b>Upload Teacher's Answer Sheet:</b></label>
            <input type="file" id="teacher-file" accept=".doc,.docx,.pdf,.jpg,.jpeg,.png,.txt">
        </div>
        <div class="file-upload">
            <label for="student-file" id="label-student-file"><b>Upload Student's Answer Sheet:</b></label>
            <input type="file" id="student-file" accept=".doc,.docx,.pdf,.jpg,.jpeg,.png,.txt">
        </div>
        <div>
            <button id="check-homework-btn">Get Result</button>
        </div>
        <div class="generated-content">
            <div id="content-output"></div>
        </div>
        <div id="hwc-actions" 
                style="
                    margin-top: 10px; 
                    display: flex;
                    justify-content: flex-end; 
                    gap: 10px;
                    align-items: center;
                    width: 100%;
                ">
                <button id="clear-hwc"
                    style="
                        padding: 10px; 
                        color: white; 
                        border: none;
                        border-radius: 4px; 
                        cursor: pointer; 
                        display: flex;
                        align-items: center;
                        width: 100px;
                        justify-content: center;
                    ">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" 
                        stroke="currentColor" 
                        stroke-width="2" 
                        stroke-linecap="round" 
                        stroke-linejoin="round" 
                        style="width: 16px; height: 16px; margin-right: 5px;"
                    >
                        <polyline points="3 6 5 6 21 6"></polyline>
                        <path d="M19 6L17.5 20a2 2 0 0 1-2 2H8.5a2 2 0 0 1-2-2L5 6m5 10v4m4-4v4"></path>
                        <line x1="10" y1="11" x2="10" y2="17"></line>
                    </svg>
                    Clear
                </button>
            </div>
    </div>
    <?php
    return ob_get_clean();
}
// [End] Function to display the Homework Checker UI ###################################################################################################################



// [Start] Function to check membership details #######################################################################################################################################################
function homcheck_check_membership_level() {
    if (is_user_logged_in()) {
        $user_id = get_current_user_id();
        $membership_level = pmpro_getMembershipLevelForUser($user_id);

        if ($membership_level) {
            return array(
                'level_id' => $membership_level->id,
                'level_name' => $membership_level->name
            );
        } else {
            return new WP_Error('no_membership', 'No membership level found.');
        }
    } else {
        return new WP_Error('not_logged_in', 'User is not logged in.');
    }
}
// [End] Function to check membership details #######################################################################################################################################################



// [Start] Function to call the OpenAI API and get a response ###########################################################################################################
function openai_api_call($model, $prompt) {
    error_log("entered >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
    $level_1_name = 'EduAI Hub Free Plan';
    $level_2_name = 'EduAI Hub Plus';
    $level_3_name = 'EduAI Hub Enterprise';
    $reset_time_in_seconds = 10800; // You can change this value as per your requirement (300 seconds = 5 minutes)

    if (empty($membership_level)) {
        return '<div class="membership-required-message" style="
                    text-align: center; 
                    max-width: 500px; 
                    margin: 100px auto; 
                    padding: 30px; 
                    background-color: #f8f9fa; 
                    border-radius: 8px; 
                    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                ">
                    <h3 style="color: #333; margin-bottom: 15px; font-size: 24px;">Membership Required</h3>
                    <p style="color: #555; margin-bottom: 20px; font-size: 16px;">You need to purchase a membership to access this feature.</p>
                    <a href="http://localhost/eduaihub/shop/"  
                    class="button" 
                    style="
                        display: inline-block;
                        background-color: #0073aa;
                        color: white;
                        padding: 10px 20px;
                        text-decoration: none;
                        border-radius: 4px;
                        font-weight: bold;
                        transition: background-color 0.3s;
                    "
                    onmouseover="this.style.backgroundColor=\'#005177\'"
                    onmouseout="this.style.backgroundColor=\'#0073aa\'"
                    >View Membership Options</a>
                </div>';
    }

    


    $level_1_usage_limit = trim(get_option('homework_checker_free_plan_limit'));
    $level_1_usage_limit = $level_1_usage_limit === '' ? null : $level_1_usage_limit;
    
    $level_2_usage_limit = trim(get_option('homework_checker_plus_plan_limit'));
    $level_2_usage_limit = $level_2_usage_limit === '' ? null : $level_2_usage_limit;


    $level_3_usage_limit = null;

    $api_key = get_option('openai_api_key');
    error_log("API key >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>".$api_key);

    if (!$api_key) {
        error_log("Error: OpenAI API key is missing @@@@@@@@@@@@@@@@@@@@@@@.");
        return new WP_Error('no_api_key', 'OpenAI API key is missing.');
    }

    // Call the function to check the user's membership level ########################################################################
    $membership_data = dok_check_membership_level();
    error_log("API key >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>".$membership_data);

    // If there is an error in membership, return the error ##########################################################################
    if (is_wp_error($membership_data)) {
        return $membership_data;
    }

    // Extract membership details ####################################################################################################
    $level_id = $membership_data['level_id'];
    $level_name = $membership_data['level_name'];

    // Define the usage limit based on membership level #############################################################################
    $usage_limit = null;
    $user_id = get_current_user_id();

    if ($level_id == 1 && $level_name == $level_1_name) {
        $usage_limit = $level_1_usage_limit;

        error_log("__________ HWC homework_checker_free_plan_limit _____ " .$level_1_usage_limit);
    } elseif ($level_id == 2 && $level_name == $level_2_name) {
        $usage_limit = $level_2_usage_limit;

        error_log("__________ HWC homework_checker_plus_plan_limit _____ " .$level_2_usage_limit);
    } elseif ($level_id == 3 && $level_name == $level_3_name) {
        $usage_limit = $level_3_usage_limit;

        error_log("__________ HWC level_3_usage_limit _____ " .$level_3_usage_limit);
    }

    error_log("Dynamic Usage Limit Applied for homework checker >>>>>>>>>>>>>>>>: " . ($usage_limit !== null ? $usage_limit : 'No limit for this plan'));



    // Check if the user has hit the usage limit, if applicable ######################################################################
    if ($usage_limit !== null) {
        $current_usage = get_user_meta($user_id, 'hc_openai_api_usage', true);
        $current_usage = $current_usage ? intval($current_usage) : 0;
        error_log("Current API Usage for User ID @@@@@@@@@@@@@@@@@@@@@@@@ $user_id: $current_usage");
        // Get the current time (Unix timestamp) and the last time the user hit their usage limit.
        $current_time = time();
        $last_usage_time = get_user_meta($user_id, 'hc_last_usage_time', true);

        // If the user has reached the usage limit
        if ($current_usage >= $usage_limit) {
            // Check if the user is on the Plus Plan

            if ($level_name == $level_2_name) {
                // Check if last usage time is set and if the reset time has not passed
                if ($last_usage_time && ($current_time - intval($last_usage_time)) < $reset_time_in_seconds) {
                    // If the reset time has not passed, inform the user to wait
                    wp_send_json_error('You have reached your tool usage limit. Please wait for 3 Hours before trying again.');
                    return;
                } else {
                    // If the reset time has passed, reset the usage counter and update the last usage time
                    update_user_meta($user_id, 'hc_openai_api_usage', 0);
                    update_user_meta($user_id, 'hc_last_usage_time', $current_time); // Update the last usage time
                    $current_usage = 0; // Reset the usage counter
                }
            } else {
                // For Free Plan users, inform them about upgrading
                wp_send_json_error('You have reached your tool usage limit. Please upgrade to the Plus or Enterprise plan for higher usage or unlimited access.');
                return;
            }
        }
        
        // Save the last usage time when the limit is hit
        if ($usage_limit !== null && $current_usage >= $usage_limit) {
            update_user_meta($user_id, 'hc_last_usage_time', time());
        }
    }

    // Step 1: Check for the user's personal API key if they belong to the Enterprise membership (ID = 3)
    $api_key = null;
    if ($level_id == 3 && $level_name == $level_3_name) {
        // Fetch the personal API key using get_option
        $user_personal_api_key = get_user_meta($user_id, 'user_openai_api_key', true);
        error_log(" user's personal API key>>>>>>>>>>>>>>>>>>>.: $user_personal_api_key");


        if ($user_personal_api_key) {
            $api_key = $user_personal_api_key;
            error_log("Using user's personal API key>>>>>>>>>>>>>>>>>>>.: $api_key");
        } else {
            error_log("User does not have a personal API key, falling back to the default backend API key.");
        }
    }

    // Step 2: Fallback to the default backend API key if no personal API key is found
    if (!$api_key) {
        $api_key = get_option('openai_api_key');
    }

    if (!$api_key) {
        error_log("Error: OpenAI API key is missing @@@@@@@@@@@@@@@@@@@@@@@.");
        return new WP_Error('no_api_key', 'OpenAI API key is missing.');
    }
    
    $url = 'https://api.openai.com/v1/chat/completions';

    // Prepare the data to be sent in the API request ##################################################################
    $data = array(
        'model' => $model,
        'messages' => array(
            array('role' => 'user', 'content' => $prompt)
        ),
        'max_tokens' => 500,
        'temperature' => 0.2,
    );

    // Set the headers for the API request ##############################################################################
    $headers = array(
        'Authorization' => 'Bearer ' . $api_key,
        'Content-Type' => 'application/json',
    );

    // Make the API request using wp_remote_post #########################################################################
    $response = wp_remote_post($url, array(
        'headers' => $headers,
        'body' => json_encode($data),
    ));

    // Check if the API request returned an error #######################################################################
    if (is_wp_error($response)) {
        return new WP_Error('api_error', 'Error in contacting the API: ' . $response->get_error_message());
    }

    // Decode the API response ##########################################################################################
    $body = json_decode(wp_remote_retrieve_body($response), true);
    $response_code = wp_remote_retrieve_response_code($response);

    if ($response_code === 200 && isset($body['choices'][0]['message']['content'])) {
        if ($usage_limit !== null) {
            $current_usage = get_user_meta($user_id, 'hc_openai_api_usage', true);
            $current_usage = $current_usage ? intval($current_usage) : 0;
            update_user_meta($user_id, 'hc_openai_api_usage', $current_usage + 1);
        }
        // Convert newlines to HTML line breaks ##########################################################################
        $formattedResponse = nl2br($body['choices'][0]['message']['content']);
        // Send the formatted response as a JSON success #################################################################
        wp_send_json_success($formattedResponse); 
    } else {
        // Send an error if the API response is invalid ##################################################################
        wp_send_json_error('Invalid API response.');
    }
}
// [End] Function to call the OpenAI API and get a response ###########################################################################################################

// [Start] Function to handle the AJAX request and check the homework ##################################################################################################
// function handle_homework_check() {
//     if (isset($_FILES['teacher_file']) && isset($_FILES['student_file'])) {
//         $teacher_file = $_FILES['teacher_file'];
//         $student_file = $_FILES['student_file'];

//          // Extract content from the uploaded files based on their file types ###############################################################
//         $teacher_file_content = extract_file_content($teacher_file['tmp_name'], $teacher_file['type']);
//         $student_file_content = extract_file_content($student_file['tmp_name'], $student_file['type']);
//         // $teacher_file_content = extract_text_and_normalize($teacher_file['tmp_name']);
//         // $student_file_content = extract_text_and_normalize($student_file['tmp_name']);

//         $fallback_result = compare_answers($teacher_file_content, $student_file_content);

//         if ($fallback_result) {
//             // If the simple comparison finds all answers correct, return that result
//             wp_send_json_success($fallback_result);
//         } else {
//             // if (empty($teacher_file_content) || empty($student_file_content)) {
//             //     error_log('File content extraction failed.');
//             //     wp_send_json_error('Failed to extract content from one or both files.');
//             //     return;
//             // }

//             // Define the model and prompt for the OpenAI API ###################################################################################
//             $model = 'gpt-3.5-turbo';
//             $prompt = "Compare the following answers:\n\nTeacher's answers:\n$teacher_file_content\n\nStudent's answers:\n$student_file_content\n\n
//                 Identify which of the student's answers are incorrect. For each incorrect answer, only show the option selected by the student and explain why it is wrong, without mentioning the correct answer explicitly. 
//                 Use the following format and ensure that you follow this format exactly:
//                 \n\nCorrect Answers:\n1. [Answer]\n2. [Answer]\n...\n\nIncorrect Answers:\n1. [Student's Incorrect Answer] - [Explanation of why it is wrong]\n2. [Student's Incorrect Answer] - [Explanation of why it is wrong]\n...\n\nSummary: [Summary of performance]
//                 \n\nIf student's answer are all correct then just give response as student's all answer are correct.
//             ";

//             $response = openai_api_call($model, $prompt);

//             // If the API call returns an error, log it and send a JSON error response ##########################################################
//             if (is_wp_error($response)) {
//                 error_log('API Error: ' . $response->get_error_message());
//                 wp_send_json_error('OpenAI API Error: ' . $response->get_error_message());
//             } else {
//                 wp_send_json_success($response);
//             }
//         }
//     } else {
//         error_log('Invalid request. Files are missing.');
//         wp_send_json_error('Invalid request. Files are missing.');
//     }
// }

function handle_homework_check() {
    // Check if required files and question type are set
    if (!isset($_FILES['teacher_file']) || !isset($_FILES['student_file']) || !isset($_POST['question_type'])) {
        error_log('Missing files or question type');
        wp_send_json_error('Please provide all required files and select question type.');
        return;
    }

    $teacher_file = $_FILES['teacher_file'];
    $student_file = $_FILES['student_file'];
    $question_type = sanitize_text_field($_POST['question_type']);

    // Extract content from files
    $teacher_content = extract_file_content($teacher_file['tmp_name'], $teacher_file['type']);
    $student_content = extract_file_content($student_file['tmp_name'], $student_file['type']);

    // Check if content extraction was successful
    if (empty($teacher_content) || empty($student_content)) {
        error_log('File content extraction failed');
        wp_send_json_error('Failed to extract content from uploaded files.');
        return;
    }

    // Handle different question types
    if ($question_type === 'mcq') {
        handle_mcq_submission($teacher_content, $student_content);
    } else {
        handle_subjective_submission($teacher_content, $student_content);
    }
}

// Updated handle_subjective_submission function
// Updated handle_subjective_submission function
function handle_subjective_submission($teacher_content, $student_content) {
    // Get API key from the global credentials hub
    $api_key = get_option('openrouter_api_key'); // Updated to match the global hub option name
    
    // Check if API key exists and is not empty
    if (!$api_key || trim($api_key) === '') {
        error_log('OpenRouter API key missing or empty in global credentials hub');
        wp_send_json_error('OpenRouter API key is not configured. Please ask the administrator to set up the API key in EDUAI Global Credentials Hub.');
        return;
    }

    $url = 'https://openrouter.ai/api/v1/chat/completions';
    
    // Create image URLs for base64 content
    $teacher_image = "data:image/jpeg;base64," . $teacher_content;
    $student_image = "data:image/jpeg;base64," . $student_content;
    
    $system_prompt = "You are an expert teacher evaluating student answers. Compare the teacher's model answer with the student's answer in the images provided. Analyze thoroughly and provide a short evaluation using the following format:

1. Strengths\n\n
- List specific strengths with clear examples\n
- Include detailed observations about what the student did well[Score/10]\n
- Mention any particularly good points or approaches used [Score/10]\n\n

2. Points Breakdown\n\n
- Concept Understanding: [Score/10]\n
- Expression Clarity: [Score/10]\n
- Grammar and Spelling: [Score/10]\n
- Overall Presentation: [Score/10]\n\n

3. Areas for Improvement\n\n
- List specific areas where the student can improve\n
- Provide actionable suggestions for enhancement\n
- Include concrete examples where possible\n\n

Overall Score: [X/10]\n\n
Summary:\n
Provide a 1-2 sentence summary highlighting key strengths and primary areas for improvement. Include specific recommendations for the student to focus on for future improvement.\n\n";
    
    $messages = array(
        array(
            'role' => 'system',
            'content' => $system_prompt
        ),
        array(
            'role' => 'user',
            'content' => array(
                array(
                    'type' => 'text',
                    'text' => "Compare these two answers. The first image is the teacher's model answer and the second is the student's answer."
                ),
                array(
                    'type' => 'image_url',
                    'image_url' => array(
                        'url' => $teacher_image
                    )
                ),
                array(
                    'type' => 'image_url',
                    'image_url' => array(
                        'url' => $student_image
                    )
                )
            )
        )
    );

    try {
        error_log('Making OpenRouter API request with key: ' . substr($api_key, 0, 5) . '...');
        
        $response = wp_remote_post($url, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
                'HTTP-Referer' => get_site_url(),
                'X-Title' => 'Homework Checker'
            ),
            'body' => json_encode(array(
                'model' => 'x-ai/grok-2-vision-1212',
                'messages' => $messages,
                'max_tokens' => 2000,
                'temperature' => 0.3
            )),
            'timeout' => 60
        ));

        if (is_wp_error($response)) {
            error_log('OpenRouter API Error: ' . $response->get_error_message());
            wp_send_json_error('API Error: Unable to connect to the evaluation service. Please try again.');
            return;
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        error_log('OpenRouter API Response Code: ' . $response_code);
        error_log('OpenRouter API Response Body: ' . substr($response_body, 0, 500) . '...');

        if ($response_code !== 200) {
            error_log('OpenRouter API returned non-200 status: ' . $response_code);
            wp_send_json_error('API Error: Service returned status code ' . $response_code);
            return;
        }

        $body = json_decode($response_body, true);
        if (!isset($body['choices'][0]['message']['content'])) {
            error_log('Invalid response format from OpenRouter API');
            wp_send_json_error('Invalid response format from the evaluation service.');
            return;
        }

        update_user_submission_count();
        wp_send_json_success($body['choices'][0]['message']['content']);

    } catch (Exception $e) {
        error_log('Exception in OpenRouter API call: ' . $e->getMessage());
        wp_send_json_error('An unexpected error occurred. Please try again.');
    }
    
}

function handle_mcq_submission($teacher_content, $student_content) {
    $fallback_result = compare_answers($teacher_content, $student_content);
    
    if ($fallback_result) {
        wp_send_json_success($fallback_result);
        return;
    }

    $model = 'gpt-3.5-turbo';
    // $prompt = "Compare the following answers:\n\nTeacher's answers:\n$teacher_content\n\nStudent's answers:\n$student_content\n\n" .
    //     "Identify which of the student's answers are incorrect. For each incorrect answer, only show the option selected by the student and explain why it is wrong, without mentioning the correct answer explicitly. " .
    //     "Use the following format exactly:\n\n" .
    //     "Correct Answers:\n1. [Answer]\n2. [Answer]\n...\n\n" .
    //     "Incorrect Answers:\n1. [Student's Incorrect Answer] - [Explanation of why it is wrong]\n2. [Student's Incorrect Answer] - [Explanation of why it is wrong]\n...\n\n" .
    //     "Summary: [Summary of performance]\n\n" .
    //     "If all answers are correct, respond with: 'All answers are correct.'";
    $prompt = "Compare the following answers and provide a detailed evaluation:\n\n" .
          "**Teacher's Answers:**\n$teacher_content\n\n" .
          "**Student's Answers:**\n$student_content\n\n" .
          "**Instructions:**\n" .
          "1. Identify which of the student's answers are incorrect.\n" .
          "2. For each incorrect answer, display only the option selected by the student and explain why it is wrong. Do not mention the correct answer explicitly.\n" .
          "3. Use the following format exactly:\n\n" .
          "**Correct Answers:**\n" .
          "1. [Answer]\n" .
          "2. [Answer]\n" .
          "...\n\n" .
          "**Incorrect Answers:**\n" .
          "1. [Student's Incorrect Answer] - [Explanation of why it is wrong]\n" .
          "2. [Student's Incorrect Answer] - [Explanation of why it is wrong]\n" .
          "...\n\n" .
          "**Summary:** [Summary of performance]\n\n" .
          "If all answers are correct, respond with: 'All answers are correct.'\n\n" .
          "**Additional Notes:**\n" .
          "- Ensure the explanations are clear and concise.\n" .
          "- Maintain a consistent format throughout the response.\n" .
          "- The summary should provide an overall assessment of the student's performance.";

    $response = openai_api_call($model, $prompt);

    if (is_wp_error($response)) {
        error_log('OpenAI API Error: ' . $response->get_error_message());
        wp_send_json_error('Error processing submission. Please try again.');
        return;
    }

    wp_send_json_success($response);
}

// Helper function to update user submission count
function update_user_submission_count() {
    if (is_user_logged_in()) {
        $user_id = get_current_user_id();
        $current_count = get_user_meta($user_id, 'submission_count', true);
        $new_count = ($current_count) ? $current_count + 1 : 1;
        update_user_meta($user_id, 'submission_count', $new_count);
    }
}
// [End] Function to handle the AJAX request and check the homework ##################################################################################################


// [Start] Function to extract text content from uploaded files based on their file types #############################################################################
// function extract_file_content($file_path, $file_type) {
//     $content = '';
//     switch ($file_type) {
//         // Extract text from PDF ####################################################################################
//         case 'application/pdf':
//             $content = hwc_extract_text_from_pdf($file_path); 
//             break;
//         // Extract text from DOCX ###################################################################################
//         case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
//             $content = extract_text_from_docx($file_path);
//             break;
//         // Extract text from plain text file ########################################################################
//         case 'text/plain':
//             $content = file_get_contents($file_path);
//             break;
//         // Log an error if the file type is unsupported #############################################################
//         default:
//             error_log("Unsupported file type: $file_type");
//             break;
//     }
//     return $content;
// }

// Function to extract file content based on question type and file type
function extract_file_content($file_path, $file_type) {
    // Handle image files for subjective questions
    if (strpos($file_type, 'image/') === 0) {
        return encode_image_to_base64($file_path);
    }

    // Handle document files for MCQ questions
    $content = '';
    switch ($file_type) {
        case 'application/pdf':
            $content = hwc_extract_text_from_pdf($file_path);
            break;
        case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
            $content = extract_text_from_docx($file_path);
            break;
        case 'text/plain':
            $content = file_get_contents($file_path);
            break;
        default:
            error_log("Unsupported file type: $file_type");
            return null;
    }
    return $content;
}


// Function to encode image to base64
function encode_image_to_base64($file_path) {
    if (!file_exists($file_path)) {
        error_log("File does not exist: $file_path");
        return null;
    }
    
    $binary = file_get_contents($file_path);
    if ($binary === false) {
        error_log("Failed to read file: $file_path");
        return null;
    }
    
    return base64_encode($binary);
}
// [End] Function to extract text content from uploaded files based on their file types #############################################################################


// Include the necessary libraries for PDF and DOCX parsing ##########################################################################################################
use Smalot\PdfParser\Parser;
use PhpOffice\PhpWord\IOFactory;

// [Start] Function to extract text from a PDF file using the Smalot/PdfParser library ###############################################################################
// function hwc_extract_text_from_pdf($file_path) {
//     $parser = new Parser();
//     $pdf = $parser->parseFile($file_path);
//     return $pdf->getText();
// }

function hwc_extract_text_from_pdf($file_path) {
    $parser = new Parser();
    $pdf = $parser->parseFile($file_path);
    $text = $pdf->getText();

    // Normalize the text
    $text = preg_replace('/\s+/', ' ', $text); // Replace multiple spaces or newlines with a single space
    $text = trim($text); // Remove leading and trailing whitespace
    $text = strtolower($text); // Convert text to lowercase for uniform comparison
    $text = preg_replace('/[^\w\s]/', '', $text); // Remove non-alphanumeric characters except spaces

    return $text;
}
// [End] Function to extract text from a PDF file using the Smalot/PdfParser library ###############################################################################


// [Start] Function to extract text from a DOCX file using the PhpOffice/PhpWord library ############################################################################
// function extract_text_from_docx($file_path) {
//     $phpWord = IOFactory::load($file_path);
//     $text = '';
    
//     // Loop through the sections and elements of the DOCX file to extract text ###############################################
//     foreach ($phpWord->getSections() as $section) {
//         foreach ($section->getElements() as $element) {
//             if (method_exists($element, 'getText')) {
//                 $text .= $element->getText() . "\n";
//             }
//         }
//     }
    
//     return $text;
// }

function extract_text_from_docx($file_path) {
    $phpWord = IOFactory::load($file_path);
    $text = '';
    
    // Loop through the sections and elements of the DOCX file to extract text
    foreach ($phpWord->getSections() as $section) {
        foreach ($section->getElements() as $element) {
            if (method_exists($element, 'getText')) {
                $text .= $element->getText() . " ";
            }
        }
    }

    // Clean up the extracted text
    $text = preg_replace('/\s+/', ' ', $text); // Replace multiple spaces or newlines with a single space
    $text = trim($text); // Remove leading and trailing whitespace
    $text = strtolower($text); // Convert text to lowercase for uniform comparison
    $text = preg_replace('/[^\w\s]/', '', $text); // Remove non-alphanumeric characters except spaces

    return $text;
}


// [End] Function to extract text from a DOCX file using the PhpOffice/PhpWord library ############################################################################


// [Start] Function to extract text from a plain text file #########################################################################################################
function extract_text_from_txt($file_path) {
    return file_get_contents($file_path);
}
// [End] Function to extract text from a plain text file ###########################################################################################################


function compare_answers($teacher_text, $student_text) {
    // Simple comparison: If texts are identical, assume all answers are correct
    if ($teacher_text === $student_text) {
        return "All answers are correct.";
    }

    // If not identical, return null to proceed with AI-driven comparison
    return null;
}

?>